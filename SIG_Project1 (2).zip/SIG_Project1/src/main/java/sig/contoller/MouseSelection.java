/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sig.contoller;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import sig.model.Invoice_Line;
import sig.view.Frame;


/**
 *
 * @author LG
 */
public class MouseSelection implements ListSelectionListener{
  
   public static int row;
   
    @Override
    public void valueChanged(ListSelectionEvent e) {
        if (!e.getValueIsAdjusting())
        {
              int Total=0;
        int n=0;  
      row = Frame.Table1.getSelectedRow();
      int r=0;  
         for (int i1=0;i1<Frame.Table2.getRowCount();i1++)
              {
                           
                               for (int j1=0;j1<Frame.Table2.getColumnCount();j1++)
              {
                                Frame.Table2.setValueAt("", i1, j1);
              }
              }
        int k=0;
        
        if (Frame.Table1.getValueAt(row, 0)!=null)
               {
          while (r<Invoice_Line.Inv_L1.size()/4)
          { 
              
             if (Invoice_Line.Inv_L1.get(k).equals(Frame.Table1.getValueAt(row, 0).toString()))
              { 
               
              for (int i=0;i<4;i++)
              {
               Frame.Table2.setValueAt(Invoice_Line.Inv_L1.get(i+k), n, i);
              } 
                 Frame.Table2.setValueAt(Integer.parseInt(Invoice_Line.Inv_L1.get(2+k))*Integer.parseInt(Invoice_Line.Inv_L1.get(3+k).trim()), n, 4);
              
              n=n+1;
              }
           k=k+4;
           r=r+1;
               }   
          }
     for (int i1=0;i1<Frame.Table2.getRowCount();i1++)
     {
         if(!"".equals(Frame.Table2.getValueAt(i1, 4).toString()))
         {
     Total = Integer.parseInt(Frame.Table2.getValueAt(i1, 4).toString())+Total;
             }
     }
         Frame.Table1.setValueAt(Total,row,3);
         if (Frame.Table1.getValueAt(row, 0)!=null)
  {
      
     Frame.InvNo.setText(Frame.Table1.getValueAt(row, 0).toString());
     Frame.CustName.setText(Frame.Table1.getValueAt(row,2).toString());
    Frame.InvDate.setText(Frame.Table1.getValueAt(row,1).toString());
    Frame.Invoice_Total.setText(Frame.Table1.getValueAt(row,3).toString());
  }
  else
  {
    Frame.InvNo.setText("");
     Frame.CustName.setText("");
    Frame.InvDate.setText("");
  } 
        
    }
    }// Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    

    


