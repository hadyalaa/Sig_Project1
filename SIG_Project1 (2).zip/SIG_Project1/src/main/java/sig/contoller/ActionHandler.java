/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sig.controller;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import sig.contoller.MouseSelection;
import sig.model.Invoice_Head;
import static sig.model.Invoice_Head.Inv_H1;
import sig.model.Invoice_Line;
import static sig.model.Invoice_Line.Inv_L1;
import sig.view.Frame;



/**
 *
 * @author LG
 */
public class ActionHandler implements ActionListener {
    public static int j=0;
    public static int j2=0;
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
   switch (e.getActionCommand())
   {
       case "Create New Invoice" -> create_Inv();
  case "Save" -> {
      System.out.println("save");
      
      Save_Inv();
            }
        
    case "Save File" -> {System.out.println("Save_File");
            saveContent();
    }
case "Load File" -> {
    System.out.println("Load_File");
    
    LoadContent();
            }
       
      case "Delete Invoice" -> {
          System.out.println("Delete_Invoice");
          Delete_Inv();
            }
      
      case "Delete Item" -> {
          System.out.println("Cancel");
          Cancel_Inv();
            }
      case "New Item" -> {
          System.out.println("New Item");
         New_Item();
            }
    }    

}
    
    //////////Functions///////////////////
//1.Create invoice function
     private static void create_Inv()
   {
Frame.InvDate.setText(null);
 Frame.CustName.setText(null);
  int Count;
if (Integer.parseInt(Frame.InvNo.getText())==Invoice_Head.Inv_H1.size()/3)
{
Count= Integer.valueOf(Frame.InvNo.getText())+1;
}
else
{
   Count= Invoice_Head.Inv_H1.size()/3+1;
}
Frame.InvNo.setText(String.valueOf(Count));
for (int i=0;i<Frame.Table2.getRowCount();i++)
{
    for (j=0;j<Frame.Table2.getColumnCount();j++)
    {
Frame.Table2.setValueAt("", i, j);
    }
    
}
 int input=JOptionPane.showConfirmDialog(null, "Do you want to create new Item Invoice ?", "Save Confirmation", JOptionPane.DEFAULT_OPTION);
      if (input ==0)
      {
 JTextField InvoiceNumber=new JTextField();
      JTextField CustomerName=new JTextField();
      JTextField Date=new JTextField();
      Object[]Fields={"InvoiceNumber",InvoiceNumber,"CustomerName",CustomerName,"Date",Date};
      
      JOptionPane.showConfirmDialog(null,Fields,"Please Enter the below",JOptionPane.OK_CANCEL_OPTION);   
      Inv_H1.add(InvoiceNumber.getText());
      Inv_H1.add(CustomerName.getText());
      Inv_H1.add(Date.getText());
      for (int i=0;i<Frame.Table1.getRowCount();i++)
      {
                      

          if (Frame.Table1.getValueAt(i,0)==null)
          {
              System.out.println("hh");
      Frame.Table1.setValueAt( Inv_H1.get(Inv_H1.size()-3), i, 0); 
      Frame.Table1.setValueAt(  Inv_H1.get(Inv_H1.size()-2), i, 1); 
      Frame.Table1.setValueAt(  Inv_H1.get(Inv_H1.size()-1), i, 2); 
      
     break;
          }
      }
      }
   }
//2.Save invoice function
     private static void Save_Inv()
   {
  
       int input=JOptionPane.showConfirmDialog(null, "Do you want to save ?", "Save Confirmation", JOptionPane.DEFAULT_OPTION);
       if (input==0)
       {
       String[] InvData=new String[3];
      InvData[0]=Frame.CustName.getText();
      InvData[1]=Frame.InvDate.getText();
      InvData[2]=Frame.InvNo.getText();
      
      if (Invoice_Head.Inv_H1.contains(InvData[2]))
      {
Invoice_Head.Inv_H1.set(Invoice_Head.Inv_H1.indexOf(InvData[2])+2, InvData[0]);
Invoice_Head.Inv_H1.set(Invoice_Head.Inv_H1.indexOf(InvData[2])+1, InvData[1]);

int k=0;
int Count1=0;
int Count2=0;
int j1;
int Index1=0;
int Index2=0;
for (j1=0;j1<Invoice_Line.Inv_L1.size()/4;j1++)
{   
   
     if ( Invoice_Line.Inv_L1.get(k).equals(InvData[2]))
            {            
Count2++;
Index1=Invoice_Line.Inv_L1.indexOf(Invoice_Line.Inv_L1.get(k));
 Index2=Invoice_Line.Inv_L1.indexOf(Invoice_Line.Inv_L1.get(k))+Count2*4;
        }
     k=k+4;
    
}
for (j1=0;j1<Frame.Table2.getRowCount();j1++)
{
 if ( Frame.Table2.getValueAt(j1, 0).toString().equals(InvData[2]))
            {
Count1++;
        }
}

 if (Count1>Count2)
     {
        
for (int i=0;i<4;i++)
{ 
          Invoice_Line.Inv_L1.add(Index2+i,Frame.Table2.getValueAt(Count1-1, i).toString());    
    }

}

k=0;
for (j1=0;j1<Frame.Table2.getRowCount();j1++)
{   
    
     if ( Frame.Table2.getValueAt(j1, 0).toString().equals(InvData[2])&&Count1<=Count2)
     {
        
for (int i=0;i<4;i++)
{ 
          Invoice_Line.Inv_L1.set(Index1+i,Frame.Table2.getValueAt(j1, i).toString());
    }

}
     
Index1=Index1+4;
      }
      }  
      else 
      {
         
          Invoice_Head.Inv_H1.add(InvData[2]);   
Invoice_Head.Inv_H1.add(InvData[1]);
 Invoice_Head.Inv_H1.add(InvData[0]);
      
      for (int j1=0;j1<Frame.Table2.getRowCount();j1++)
{
    
      
for (int i=0;i<4;i++)
{
    Invoice_Line.Inv_L1.add(Frame.Table2.getValueAt(j1, i).toString());
       
    }
}
      }
      
      int k=0;
  for (j=0;j<Inv_H1.size()/3;j++)
             {
                 for (int i=0;i<3;i++)
                 {
                  
                    Frame.Table1.setValueAt(Inv_H1.get(i+k),j, i); 
                 }
                 k=k+3;
             }
       }
}
       
      
   
      

      

   
   
   
   
 //3.Delete invoice function  
     private static void Delete_Inv()
     {
   int row_Sel= Frame.Table1.getSelectedRow();
        int k=0;  
   for (int j=0;j<Inv_H1.size()/3;j++)
             { 
                 if (Inv_H1.get(k).equals(String.valueOf(row_Sel+1)))
                 {  
                   for (int i=0;i<3;i++)
                   {
                      
               
                System.out.println(row_Sel+1);
            Inv_H1.remove(k);
          Frame.Table1.setValueAt( "",row_Sel, i);
          Frame.Table1.setValueAt( "",row_Sel, 3);
          
                   }
                     }
                    k=k+3;                      
             }
   
   k=0;
          
              for (int j=0;j<Inv_L1.size()/4;j++)
             { 
                 
                       
                if (Inv_L1.get(k).equals(Frame.InvNo.getText()))
                 {  
                 for (int i=0;i<4;i++)
                   {
        
            Invoice_Line.Inv_L1.remove(k);
            for (int r1=0;r1<Frame.Table2.getRowCount();r1++)
            {
                for (int r2=0;r2<Frame.Table2.getColumnCount();r2++)
                {
          Frame.Table2.setValueAt( "",r1, r2);
        
                }
         
            }
          
                   }
                     }
                    k=k+4;                      
             }    
     }
           
          
     
     

  


//4.Save Content function   
private  void saveContent()
{
    JFileChooser fc=new JFileChooser();
    int result=fc.showSaveDialog(Frame.Save_File);
    if(result==JFileChooser.APPROVE_OPTION)
    {
        String path=fc.getSelectedFile().getPath();
        FileWriter fos=null;
        try
        {
            fos=new FileWriter(path);
            
             String b=Invoice_Head.Inv_H1.toString();
            fos.write(b);
    }catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }catch (IOException e)
        {
            e.printStackTrace();
        }finally{
            try{
                fos.close();
            }catch(IOException e){
        }
        
        
}
   
    
    }
    JFileChooser fc2=new JFileChooser();
    int result2=fc2.showSaveDialog(Frame.Save_File);
    if(result==JFileChooser.APPROVE_OPTION)
    {
        String path=fc2.getSelectedFile().getPath();
        FileWriter fos2=null;
        try
        {
            fos2=new FileWriter(path);
            
             String b2=Invoice_Line.Inv_L1.toString();
            fos2.write(b2);
    }catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }catch (IOException e)
        {
            e.printStackTrace();
        }finally{
            try{
                fos2.close();
            }catch(IOException e){
        }
        
        
}
   
    
    }
}
     
//5.Load Content function   
private  void LoadContent()
{
   
    JFileChooser fc=new JFileChooser();
     
    int result1=fc.showOpenDialog(Frame.Load_File);
  
    if(result1==JFileChooser.APPROVE_OPTION)
    {
        String path=fc.getSelectedFile().getPath();
         FileInputStream fis=null;
          
        try
        {
            fis=new FileInputStream(path);
            int size=fis.available();
            String [] s1=new String[size];
         
            byte[] b=new byte[size];
            fis.read(b);
          String s= new String(b);
          s1[0]="";
          for (int i=0;i<size;i++)
          {
              
              if (s.charAt(i)!=','&&s.charAt(i)!='\n')
              {
                  
           s1[j]=s1[j]+String.valueOf(s.charAt(i));
           
          }
          else
          {
              if (!s1[j].isEmpty())
              {
                j=j+1;
               s1[j]="";
              }
                
               
                  }
                  }
       
         
         Invoice_Head Inv_Head1=new Invoice_Head();
        Inv_Head1.Invoice_Head1(s1); 
         
}catch(FileNotFoundException e){
}catch (IOException e){
    
}finally{
   try{ fis.close();}catch(IOException e){}
}
        
       
        
    }
    
     ///////////Load second file////
        JFileChooser fc2=new JFileChooser();
     
    int result2=fc2.showOpenDialog(Frame.Load_File);
    if(result2==JFileChooser.APPROVE_OPTION)
    {
        String path2=fc2.getSelectedFile().getPath();
         FileInputStream fis2=null;
          
        try
        {
            fis2=new FileInputStream(path2);
            int size2=fis2.available();
            String [] s2=new String[size2];
         
            byte[] b2=new byte[size2];
            fis2.read(b2);
          String s= new String(b2);
          s2[0]="";
          for (int i=0;i<size2;i++)
          {
              
              if (s.charAt(i)!=','&&s.charAt(i)!='\n')
              {
                  
           s2[j2]=s2[j2]+String.valueOf(s.charAt(i));
           
          }
          else
          {
              if (!s2[j2].isEmpty())
              {
                j2=j2+1;
               s2[j2]="";
              
              }
                 }
                  }
      
   
        Invoice_Line Inv_line1=new Invoice_Line();
        Inv_line1.Invoice_Line1(s2);
}catch(FileNotFoundException e){
}catch (IOException e){
    
}finally{
   try{ fis2.close();}catch(IOException e){}
   }
}
}
//5.Cancel function  
 private static void Cancel_Inv()
     {
       int row_Sel= Frame.Table2.getSelectedRow();
          int k=0;
          
              for (int j=0;j<Inv_L1.size()/4;j++)
             { 
                   for (int i=0;i<4;i++)
                   {
                       
                if (Inv_L1.get(k)==Frame.Table2.getValueAt(row_Sel,i))
                 {  
               
                System.out.println(k);
            Invoice_Line.Inv_L1.remove(k);
          Frame.Table2.setValueAt( "",row_Sel, i);
          Frame.Table2.setValueAt( "",row_Sel, 4);
          
                   }
                     }
                    k=k+4;                      
             }    
}
 
 
 //6.New Item function  
 private static void New_Item()
     {
       int input=JOptionPane.showConfirmDialog(null, "Do you want to create new Item ?", "Save Confirmation", JOptionPane.DEFAULT_OPTION);
      JTextField ItemName=new JTextField();
      JTextField Price=new JTextField();
      JTextField Quantity=new JTextField();
      Object[]Fields={"ItemName",ItemName,"Item Price",Price,"Quantity",Quantity};
      
      JOptionPane.showConfirmDialog(null,Fields,"Please Enter the below",JOptionPane.OK_CANCEL_OPTION);      
       if (input==0)
       {
       String[] InvData=new String[3];
      InvData[0]=Frame.CustName.getText();
      InvData[1]=Frame.InvDate.getText();
      InvData[2]=Frame.InvNo.getText();
     
     
      if (Invoice_Head.Inv_H1.contains(InvData[2])==true)
      {
       Inv_L1.add(InvData[2]);
      Inv_L1.add(ItemName.getText());
      Inv_L1.add(Price.getText());
      Inv_L1.add(Quantity.getText());
      for (int i=0;i<Frame.Table2.getRowCount();i++)
      {
          if (Frame.Table2.getValueAt(i,0)=="")
          {
      Frame.Table2.setValueAt(  Invoice_Line.Inv_L1.get(Inv_L1.size()-4), i, 0); 
      Frame.Table2.setValueAt(  Invoice_Line.Inv_L1.get(Inv_L1.size()-3), i, 1); 
      Frame.Table2.setValueAt(  Invoice_Line.Inv_L1.get(Inv_L1.size()-2), i, 2); 
      Frame.Table2.setValueAt(  Invoice_Line.Inv_L1.get(Inv_L1.size()-1), i, 3); 
     break;
          }
      }
      }
      else
      {
         Inv_H1.add(InvData[2]);
      Inv_H1.add(InvData[1]);
      Inv_H1.add(InvData[0]);
        Inv_L1.add(InvData[2]);
      Inv_L1.add(ItemName.getText());
      Inv_L1.add(Price.getText());
      Inv_L1.add(Quantity.getText());
     
      }
      int k=0;
       for (int j1=0;j1<Inv_H1.size()/3;j1++)
             {
                 
             for (int i1=0;i1<3;i1++)
             {
             Frame.Table1.setValueAt(  Invoice_Head.Inv_H1.get(i1+k), j1, i1);   
              }
              k=k+3;
             }
              
         }
       
      
}
}



