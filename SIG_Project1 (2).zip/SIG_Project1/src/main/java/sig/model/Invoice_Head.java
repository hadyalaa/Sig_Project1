/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sig.model;

import java.util.ArrayList;
import sig.view.Frame;



/**
 *
 * @author LG
 */
public class Invoice_Head {
    
     
  
       public static ArrayList<String> Inv_H1 =new ArrayList<String>() ;
    public ArrayList<String> Invoice_Head1(String[] Inv_Head1){
       int r=0;
        int k=0;
       System.out.println("Invoice_Head");
       System.out.println("\n {");
     
  while ( r < Inv_Head1.length/3)
          {
          
              for (int i=0;i<3;i++)
              {
                   
                  Inv_H1.add(i+k,Inv_Head1[i+k]);
              
              } 
           r=r+1;
           k=k+3;
       
          }
  System.out.println(Invoice_Head.Inv_H1.size());
k=0;
 while (Inv_H1.remove(null)) {
        }
 while (Inv_H1.remove("")) {
        }
        for (int j=0;j<Inv_H1.size()/3;j++)
             {
                 for (int i=0;i<3;i++)
                 {
                  System.out.print(Inv_H1.get(i+k));
                      System.out.print(",");
                      Frame.Table1.setValueAt(Inv_H1.get(i+k),j, i); 
                 }
                 k=k+3;
             }
         
 
  System.out.println("\n }");
return Inv_H1; }
}

