/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sig.model;

import java.util.ArrayList;


/**
 *
 * @author LG
 */
public class Invoice_Line {
  
       public static ArrayList<String> Inv_L1=new ArrayList<String>();
       
    public ArrayList<String> Invoice_Line1(String[] Inv_line1){
          int r2=0;
      int k2=0;
     System.out.println("Invoice_Line");
     System.out.println("\n {");
  while ( r2 < Inv_line1.length/4)
          {
              for (int i=0;i<4;i++)
              {
                  Inv_L1.add(i+k2,Inv_line1[i+k2]);
                  
          
              }
             
           r2=r2+1;
           k2=k2+4;
           
          }
  while (Inv_L1.remove(null)) {
        }
 while (Inv_L1.remove("")) {
        }

 
 
   k2=0;
  for (int j=0;j<Inv_L1.size()/4;j++)
             {
                 for (int i=0;i<4;i++)
                 {
   System.out.print(Inv_L1.get(i+k2));
            System.out.print(",");
                 }
                   k2=k2+4;
             }
  System.out.println("\n }");
return Inv_L1;
    }
}
